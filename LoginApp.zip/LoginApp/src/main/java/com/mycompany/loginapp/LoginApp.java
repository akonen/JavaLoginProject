package com.mycompany.loginapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.regex.*;

public class LoginApp {
    // Main frame and fields
    private JFrame frame;
    private JTextField usernameField, firstNameField, lastNameField, phoneNumberField;
    private JPasswordField passwordField;
    private JLabel messageLabel;
    private JCheckBox rememberMeCheckBox;
    private JButton logoutButton;
    private String registeredUsername = "";
    private String registeredPassword = "";
    private String registeredPhone = "";
    private String registeredFirstName = "";
    private String registeredLastName = "";
    private boolean isLoggedIn = false;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginApp().createAndShowGUI());
    }

    // Create and show the GUI
    private void createAndShowGUI() {
        frame = new JFrame("User Registration and Login");
        frame.setSize(400, 350);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(8, 2));

        JLabel firstNameLabel = new JLabel("First Name: ");
        firstNameField = new JTextField();

        JLabel lastNameLabel = new JLabel("Last Name: ");
        lastNameField = new JTextField();

        JLabel usernameLabel = new JLabel("Username: ");
        usernameField = new JTextField();

        JLabel passwordLabel = new JLabel("Password: ");
        passwordField = new JPasswordField();

        JLabel phoneNumberLabel = new JLabel("Cell Phone Number: ");
        phoneNumberField = new JTextField();

        rememberMeCheckBox = new JCheckBox("Remember Me");

        JButton registerButton = new JButton("Register");
        JButton loginButton = new JButton("Login");
        logoutButton = new JButton("Logout");

        messageLabel = new JLabel("", JLabel.CENTER);

        frame.add(firstNameLabel);
        frame.add(firstNameField);
        frame.add(lastNameLabel);
        frame.add(lastNameField);
        frame.add(usernameLabel);
        frame.add(usernameField);
        frame.add(passwordLabel);
        frame.add(passwordField);
        frame.add(phoneNumberLabel);
        frame.add(phoneNumberField);
        frame.add(rememberMeCheckBox);
        frame.add(registerButton);
        frame.add(loginButton);
        frame.add(logoutButton);
        frame.add(new JLabel(""));
        frame.add(messageLabel);

        logoutButton.setVisible(false); // Hide logout button by default

        // Register button action
        registerButton.addActionListener(this::registerAction);

        // Login button action
        loginButton.addActionListener(this::loginAction);

        // Logout button action
        logoutButton.addActionListener(this::logoutAction);

        // Password visibility toggle
        passwordField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                passwordField.setEchoChar((char) 0); // Show password
            }

            @Override
            public void focusLost(FocusEvent e) {
                passwordField.setEchoChar('*'); // Hide password
            }
        });

        frame.setVisible(true);
    }

    // Register action
    private void registerAction(ActionEvent e) {
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String phone = phoneNumberField.getText();

        if (checkUserName(username) && checkPasswordComplexity(password) && checkCellPhoneNumber(phone)) {
            registeredFirstName = firstName;
            registeredLastName = lastName;
            registeredUsername = username;
            registeredPassword = password;
            registeredPhone = phone;
            messageLabel.setText("Registration successful!");
        } else {
            messageLabel.setText("Please check the input data.");
        }
    }

    // Login action
    private void loginAction(ActionEvent e) {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (loginUser(username, password)) {
            isLoggedIn = true;
            messageLabel.setText("Welcome, " + registeredFirstName + " " + registeredLastName + "!");
            logoutButton.setVisible(true); // Show logout button after login
            showProfile();
        } else {
            messageLabel.setText("Username or password incorrect.");
        }
    }

    // Show user profile after successful login
    private void showProfile() {
        // Show profile details
        JOptionPane.showMessageDialog(frame,
                "Profile Details:\n" +
                        "First Name: " + registeredFirstName + "\n" +
                        "Last Name: " + registeredLastName + "\n" +
                        "Username: " + registeredUsername + "\n" +
                        "Phone Number: " + registeredPhone,
                "User Profile", JOptionPane.INFORMATION_MESSAGE);
    }

    // Logout action
    private void logoutAction(ActionEvent e) {
        isLoggedIn = false;
        messageLabel.setText("You have been logged out.");
        logoutButton.setVisible(false); // Hide logout button
        clearFields();
    }

    // Check if username is valid
    private boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Check if password meets the complexity
    private boolean checkPasswordComplexity(String password) {
        Pattern pattern = Pattern.compile("^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$");
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }

    // Check if cell phone number is valid
    private boolean checkCellPhoneNumber(String phone) {
        Pattern pattern = Pattern.compile("^\\+27\\d{9}$");
        Matcher matcher = pattern.matcher(phone);
        return matcher.matches();
    }

    // Register user and return messages
    private boolean registerUser(String firstName, String lastName, String username, String password, String phone) {
        if (!checkUserName(username)) {
            messageLabel.setText("Username is not correctly formatted.");
            return false;
        }
        if (!checkPasswordComplexity(password)) {
            messageLabel.setText("Password is not correctly formatted.");
            return false;
        }
        if (!checkCellPhoneNumber(phone)) {
            messageLabel.setText("Cell phone number is incorrectly formatted.");
            return false;
        }
        return true;
    }

    // Login user validation
    private boolean loginUser(String username, String password) {
        return username.equals(registeredUsername) && password.equals(registeredPassword);
    }

    // Clear the input fields
    private void clearFields() {
        firstNameField.setText("");
        lastNameField.setText("");
        usernameField.setText("");
        passwordField.setText("");
        phoneNumberField.setText("");
    }
}
